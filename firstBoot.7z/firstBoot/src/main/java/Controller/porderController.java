package Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import Dao.porder.implPorder;
import Model.porder;

@RestController
public class porderController {
	@GetMapping("porder")
	public ModelAndView list(HttpServletRequest request,HttpSession session)
	{
		porder p=new porder("a",1,1);
		ModelAndView modelandview=new ModelAndView("porder");
		modelandview.addObject("Porder", p);
		session.setAttribute("P", p);
		
		return modelandview;
	}
	
	@GetMapping("test")
	public ModelAndView test()
	{
		return new ModelAndView("test");
	}
	
	@RequestMapping("add")
	public String add(HttpSession session)
	{
		porder p=(porder) session.getAttribute("P");
		
		new implPorder().add(p);
		
		return "success";
	}

}
