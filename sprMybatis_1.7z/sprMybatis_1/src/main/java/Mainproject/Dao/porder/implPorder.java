package Mainproject.Dao.porder;

import java.util.List;

import Mainproject.Model.porder;

public class implPorder implements porderDao{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void add(porder p) {
		
		
	}

	@Override
	public List<porder> queryAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public porder queryId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<porder> querySum(int start, int end) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(porder p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
