package Dao.member;

import java.util.List;
import java.util.Map;

import Model.member;

public interface memberDao {
	//新增
	void add(member m);
	//read
	List<member> queryAll();
	member queryUser(String username,String password);
	member queryId(int id);
	
	//update
	
	void update(member m);
	
	//delete
	void delete(int id);
	

}
