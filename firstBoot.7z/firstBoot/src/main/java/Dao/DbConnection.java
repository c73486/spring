package Dao;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class DbConnection {

	public static void main(String[] args) {
		System.out.println(DbConnection.getDb());

	}
	
	public static SqlSession getDb()
	{
		InputStream input;
		SqlSession sqlsession=null;
		try {
			input = Resources.getResourceAsStream("Mybatis-config.xml");
			SqlSessionFactory sqlSession=new SqlSessionFactoryBuilder().build(input);
			sqlsession=sqlSession.openSession();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return sqlsession;
		
	}

}
