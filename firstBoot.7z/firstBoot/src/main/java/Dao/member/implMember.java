package Dao.member;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import Dao.DbConnection;
import Model.member;

public class implMember implements memberDao{

	public static void main(String[] args) {
		
		//new implMember().add(new member("a","abc","1234"));
		//System.out.println(new implMember().queryAll());
		System.out.println(new implMember().queryUser("b", "1234"));
		//System.out.println(new implMember().queryId(2));
		/*member m=new implMember().queryId(2);
		m.setName("test");
		new implMember().update(m);*/
		//new implMember().delete(2);
	}

	@Override
	public void add(member m) {
		SqlSession session=DbConnection.getDb();
		session.insert("memberMapper.add", m);
		session.commit();
		session.close();
		
	}

	@Override
	public List<member> queryAll() {
		SqlSession session=DbConnection.getDb();
		List<member> l=session.selectList("memberMapper.queryAll");
		return l;
	}

	@Override
	public member queryUser(String username, String password) {
		SqlSession session=DbConnection.getDb();
		Map<String,String> map=new HashMap();
		map.put("username",username);
		map.put("password", password);
		List<member> l=session.selectList("memberMapper.queryUser", map);
		
		if(l.size()!=0)
		{
			member[] m=l.toArray(new member[l.size()]);
			return m[0];
		}
		else
		{
			return null;
		}
		
	}

	@Override
	public member queryId(int id) {
		SqlSession session=DbConnection.getDb();
		List<member> l=session.selectList("memberMapper.queryId", id);
		member[] m=l.toArray(new member[l.size()]);
		if(l.size()!=0)
		{
			return m[0];
		}
		else
		{
			return null;
		}
		
	}

	@Override
	public void update(member m) {
		SqlSession session=DbConnection.getDb();
		session.update("memberMapper.update",m);
		session.commit();
		session.close();
		
	}

	@Override
	public void delete(int id) {
		SqlSession session=DbConnection.getDb();
		session.delete("memberMapper.delete", id);
		session.commit();
		session.close();
	}

	

	
	}

	

	

	


