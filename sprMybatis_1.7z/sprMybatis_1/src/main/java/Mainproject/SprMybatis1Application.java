package Mainproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprMybatis1Application {

	public static void main(String[] args) {
		SpringApplication.run(SprMybatis1Application.class, args);
	}

}
