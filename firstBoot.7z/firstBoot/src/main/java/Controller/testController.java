package Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import Dao.member.implMember;
import Model.member;


@RestController
//@Controller
@RequestMapping("/a")
public class testController {

	public static void main(String[] args) {
		

	}
	//@RequestMapping(value="/hello",method=RequestMethod.GET)
	//@RequestMapping("/hello")
	//@PostMapping("/hello")
	@GetMapping("/books")
	@ResponseBody
	public static Object getHello()
	{
		Map<String,Object> map=new HashMap();
		map.put("name","hello");
		map.put("age", 18);
		
		return map;
	}
	@GetMapping("/books/{id}/{username}")
	public static Object getOne(@PathVariable("id") long bid,@PathVariable String username)
	{
		System.out.println("--------id="+bid);
		Map<String,Object> book=new HashMap();
		book.put("name", "互聯網");
		book.put("isbn", "12345678");
		book.put("author","allen"+bid);
		book.put("username",username);
		return book;
	}
	
	@RequestMapping("/add")
	public static void add(HttpServletRequest request,HttpServletResponse response)
	{
		String name=request.getParameter("name");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		member m=new member(name,username,password);
		new implMember().add(m);
		
	}
	@RequestMapping("/queryAll")
	public static List<member> queryAll()
	{
		List<member> l=new implMember().queryAll();
		return l;
	}
	
	
	
	@RequestMapping("test")
	 public ModelAndView index() {
        ModelAndView modelAndView = new ModelAndView("test");
         return modelAndView;
    }

}
