package Dao.porder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import Dao.DbConnection;
import Model.porder;

public class implPorder implements porderDao {

	public static void main(String[] args) {
		//porder p=new porder("allen",1,2);
		//new implPorder().add(p);
		//System.out.println(new implPorder().queryAll());
		//System.out.println(new implPorder().querySum(7000, 20000));
		//System.out.println(new implPorder().queryId(10));
		
		/*porder p=new implPorder().queryId(1);
		p.setName("GJUN");
		p.setLcd(10);
		p.setRam(7);
		p.getSum();
		
		new implPorder().update(p);*/
		
		//new implPorder().delete(5);

	}

	@Override
	public void add(porder p) {
		SqlSession session=DbConnection.getDb();
		session.insert("porderMapper.add", p);
		session.commit();
		session.close();
		
	}

	@Override
	public List<porder> queryAll() {
		SqlSession session=DbConnection.getDb();
		List<porder> l=session.selectList("porderMapper.queryAll");
		return l;
	}

	@Override
	public List<porder> querySum(int start, int end) {
		SqlSession session=DbConnection.getDb();
		Map<String,Integer> map=new HashMap();
		map.put("start",start);
		map.put("end", end);
		List<porder> l=session.selectList("porderMapper.querySum", map);
		return l;
	}

	@Override
	public porder queryId(int id) {
		SqlSession session=DbConnection.getDb();
		List<porder> l=session.selectList("porderMapper.queryId", id);
		porder[] p=l.toArray(new porder[l.size()]);
		if(l.size()!=0)
		{
			return p[0];
		}
		else
		{
			return null;
		}
		
	}

	@Override
	public void update(porder p) {
		SqlSession session=DbConnection.getDb();
		session.update("porderMapper.update", p);
		session.commit();
		session.close();
		
	}

	@Override
	public void delete(int id) {
		SqlSession session=DbConnection.getDb();
		session.delete("porderMapper.delete",id);
		session.commit();
		session.close();
		
	}

}
